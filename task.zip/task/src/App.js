
import './App.css';
import Base from './Layout/base';


function App() {
  return (
      <Base/>
  );
}

export default App;
