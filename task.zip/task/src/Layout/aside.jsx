import React from 'react'



const Aside = () => {
    return (
        <aside id="left-panel" className="left-panel">
        <nav className="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" className="main-menu collapse navbar-collapse">
                <ul className="nav navbar-nav">
                    <li className="active">
                        <a href="index.html"><i className="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
                    
                    <li className="menu-item-has-children dropdown">
                        <a href="#" className="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-cogs"></i> <b>Sales</b></a>
                        <ul className="sub-menu children dropdown-menu">
                            <li><a href="ui-buttons.html">Trends</a></li>
                            <li><a href="ui-badges.html">channel</a></li>
                            <li><a href="ui-tabs.html">Purchase</a></li>
                            <li><a href="ui-cards.html">Price</a></li>
                            
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" className="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i className="menu-icon fa fa-table"></i><b>Shoppers</b></a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><a href="tables-basic.html">Womens</a></li>
                            <li><a href="tables-data.html">Mens</a></li>
                        </ul>
                    </li>
                    <li className="menu-item-has-children dropdown">
                        <a href="#" className="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i className="menu-icon fa fa-th"></i><b>Compare</b></a>
                        <ul className="sub-menu children dropdown-menu">
                            <li><i className="menu-icon fa fa-th"></i><a href="forms-basic.html">Basic </a></li>
                            <li><i className="menu-icon fa fa-th"></i><a href="forms-advanced.html">Advanced Form</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
    </aside>
        
    );
}

export default Aside;