import React,{Suspense} from 'react';
import  Footer  from './footer';
import Header  from './header'
import  Aside  from './aside';


const Base = () => {
    return (
        <React.Fragment>
            <Aside />
            <div id="right-panel" className="right-panel">
                <Header />
                <div className="content">
                    <div className="animated fadeIn">
                  
                    </div>
                </div>
                 
                <Footer />
            </div>
        </React.Fragment>
    );
}

export default Base;