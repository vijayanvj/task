import React from 'react'

const Footer = () => {
    return (
        <footer className="site-footer">
            <div className="footer-inner bg-white">
                <div className="row">
                   
                </div>
            </div>
        </footer>
    );
}

export default Footer;